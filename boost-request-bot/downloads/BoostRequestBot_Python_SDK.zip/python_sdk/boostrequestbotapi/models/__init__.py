# flake8: noqa

# import all models into this package
# if you have many models here with many references from one model to another this may
# raise a RecursionError
# to avoid this, import only the models that you directly need like:
# from from boostrequestbotapi.model.pet import Pet
# or import this package, but before doing it, use:
# import sys
# sys.setrecursionlimit(n)

from boostrequestbotapi.model.boost_request import BoostRequest
from boostrequestbotapi.model.boost_request_partial import BoostRequestPartial
from boostrequestbotapi.model.detailed_error_response import DetailedErrorResponse
from boostrequestbotapi.model.embed_field import EmbedField
from boostrequestbotapi.model.error_response import ErrorResponse
from boostrequestbotapi.model.generic_response import GenericResponse
from boostrequestbotapi.model.patch_steal_credits_request import PatchStealCreditsRequest
from boostrequestbotapi.model.user_steal_credits import UserStealCredits
