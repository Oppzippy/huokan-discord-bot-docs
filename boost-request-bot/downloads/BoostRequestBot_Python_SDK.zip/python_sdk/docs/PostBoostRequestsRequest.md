# PostBoostRequestsRequest


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requester_id** | **str** |  | 
**backend_channel_id** | **str** |  | 
**message** | **str** |  | 
**price** | **str** |  | [optional] 
**advertiser_cut** | **str** |  | [optional] 
**preferred_advertiser_ids** | **[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


